# The "current" provider uses the region selected in the Resource Manager UI
provider "oci" {
  region       = var.region
  tenancy_ocid = var.tenancy_ocid
}

# Data source to find which region is actually the "home" region
data "oci_identity_region_subscriptions" "this" {
  tenancy_id = var.tenancy_ocid

  filter {
    name   = "is_home_region"
    values = [true]
  }
}

# The "home" provider dynamically uses the home region from the data source
provider "oci" {
  alias        = "home"
  region       = data.oci_identity_region_subscriptions.this.region_subscriptions[0].region_name
  tenancy_ocid = var.tenancy_ocid
}

